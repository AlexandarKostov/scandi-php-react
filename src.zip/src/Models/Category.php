<?php

namespace App\Models;

class Category extends Model
{
    protected static string $table = 'categories';
}